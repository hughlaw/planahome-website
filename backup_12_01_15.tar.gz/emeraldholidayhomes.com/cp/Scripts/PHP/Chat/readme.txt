
	```'`'`'`'`''`''```'''`''`'`````''`''`'```'`'`'`''`'`'``
			PHP Chat - version 002a
			By Maxime Labelle - info@vt220.com

			http://www.vt220.com

	```'`'`'`'`''`''```'''`''`'`````''`''`'```'`'`'`''`'`'``

	>> INSTALLATION
	Just put the tag <?PHP include("phpchat.php"); ?> in your 
	html file and it will work. Make sure the file used for
	the database are writable, if not sure please do

	IMPORTANT: Please change the admin password, just open
		   and edit the file phpchat.php and change it.

	# chmod 777 <chat_file_name.db>
	ex: chmod 777 chat.db

	>> EYE-CANDY
	If you want to have a nice chat input box and submit buttons
	insert this code right after your </TITLE> tag in the html 
	file, like this:

	#~#~#~#~#~#~#~# STYLE SHEET FOR THE FORM IN PHP CHAT #~#~#~#~#~#~#~#

	</TITLE><STYLE type=text/css>
	INPUT.form {
		BACKGROUND-COLOR: #666666; BORDER-BOTTOM: #000000 1px solid; BORDER-LEFT: #000000 1px solid; BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid; COLOR: #ffffff; FONT-FAMILY: verdana, tahoma, arial; FONT-SIZE: 8pt;
	}
	INPUT.button {
		BACKGROUND-COLOR: #FF6600; BORDER-BOTTOM: #000000 1px solid; BORDER-LEFT: #000000 1px solid; BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid; COLOR: #ffffff; FONT-FAMILY: verdana, tahoma, arial; FONT-SIZE: 11px; FONT-WEIGHT: bold
	}
	SELECT.choice {
		BACKGROUND-COLOR: #666666; BORDER-BOTTOM: #000000 1px solid; BORDER-LEFT: #000000 1px solid; BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid; COLOR: #ffffff; FONT-FAMILY: verdana, tahoma, arial; FONT-SIZE: 8pt
	}
	</style>

	#~#~#~#~#~#~#~# STYLE SHEET FOR THE FORM IN PHP CHAT #~#~#~#~#~#~#~#

	Change the colors if you want ! 

	>> CONFIGURATION
	Just open/edit the file phpchat.php and edit the variables
	under the SETTINGS header..

	>> ABOUT
	Was written by Maxime Labelle - info@vt220.com
	for fun, because I felt like it, no reasons, works nice too..thanks
	to Silicon Ghost for some snipplets, nothing serious here, its GPL
	too, so use this code as you want...

	Maxime Labelle
	email: info@vt220.com
	web: http://www.vt220.com

	```'`'`'`'`''`''```'''`''`'`````''`''`'```'`'`'`''`'`'``

			http://www.vt220.com

