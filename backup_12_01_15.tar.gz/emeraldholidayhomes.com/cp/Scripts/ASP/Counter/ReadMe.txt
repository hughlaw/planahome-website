Web Wiz Guide Hit Counter realease v1.03 beta


The Web Wiz Guide Hit Counter v1.03 beta is written by Bruce Corkhill

****************************************************************************************
**  Copyright Notice                                                                  **
**  Copyright 2001 Bruce Corkhill All Rights Reserved.                                **
**  This script is free to use and alter as much as you like.                         **
**  You may not resell or redistribute this script without permission by the author.  **
**  You may not pass the script off as your own work.                                 **
**  You must place a link to http://www.webwizguide.com somewhere on your web site.   **
**  Use this script at your own risk						      **
****************************************************************************************

The copyright notice has been placed here as I have found people passing my scripts of as there own and I have even come across someone selling them!!


If you are having problems running the script then please post a message about the problem to the surf-net web forum at: -
	
	 http://www.webwizguide.com/forum 

your questions will be answered there NOT by e-mail



The Hit Counter uses ASP and must be run through a web sever supporting ASP.

Luckily Windows 98 comes with Personal Web Sever found on the windows 98 CD. Windows 2000 is even better as it comes with Microsoft's Web Sever, IIS 5. 

Windows NT 4 and 95 users can get a copy of Personal Web Sever by downloading NT 4 Option Pack from Microsoft. Don't be fooled by the name as it asks if you wish to download Windows 95 version.

A Text Editing program like UltraEdit is also highly recommended for editing any ASP scripts and an FTP program like Bullet FTP for uploading any scripts to your ASP enabled web space.




Using the hit counter

Unzip all the files to the same directory

Files must be run through an ASP enabled web sever

The counter digits should be in the directory named counter_images


For a Full Tutorial on writing this script goto: -

http://www.webwizguide.com/asp/tutorials/hit_counter_tutorial.asp



If you are having trouble with the script then please take a look at my FAQ's, before e-mailing me, at: -

http://www.webwizguide.com/asp/FAQ


